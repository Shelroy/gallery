import React from 'react'

import Display from './Display'
import Grid from '@material-ui/core/Grid'

function GridSystem (){

    return(

        <Display />
    )
}






export default GridSystem