
import React from "react"

function MainContent()
{
    return(
        <main className="main">This is my Main Content component</main>
    )
}

export default MainContent

