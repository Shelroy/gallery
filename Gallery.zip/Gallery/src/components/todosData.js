const todosData = [
    {
        id: 1,
        text: "Take out the trash",
        completed: true
    },
    {
        id: 2,
        text: "Grocery shopping",
        completed: false
    },
    {
        id: 3,
        text: "Clean gecko tank",
        completed: false
    },
    {
        id: 4,
        text: "Mow lawn",
        completed: true
    },
    {
        id: 5,
        text: "Catch up on Arrested Development",
        completed: false
    },
    {
        id: 6,
        text: "Catch up on Arrested Development",
        completed: false
    },
    {
        id: 7,
        text: "Catch up on Arrested Development",
        completed: false
    },
    {
        id: 8,
        text: "Catch up on Arrested Development",
        completed: false
    }
]

export default todosData