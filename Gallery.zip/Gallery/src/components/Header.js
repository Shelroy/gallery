import React from "react"


function Header()
{
    return(
        <header className="navbar">This is my header component</header>
    );
}

export default Header