import React from "react"

function ImageDetails (props) {


    
    return (
        <div>
           
            <p> {props.img.Url}</p>
        </div>
    )
    }

export default ImageDetails