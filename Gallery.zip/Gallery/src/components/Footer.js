
import React from "react"

function Footer()
{
    return(

        <footer>This is my Footer component</footer>
    )
}

export default Footer

